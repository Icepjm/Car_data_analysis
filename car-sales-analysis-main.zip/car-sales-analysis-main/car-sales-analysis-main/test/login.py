import streamlit as st


def login_page():
    """登录页面"""
    st.title("登录系统")

    # 使用表单收集登录信息
    with st.form(key="login_form"):
        username = st.text_input("用户名")
        password = st.text_input("密码", type="password")
        submit_button = st.form_submit_button("登录")

    # 处理登录逻辑
    if submit_button:
        # 简化版验证（实际应用中应从数据库验证）
        if username == "admin" and password == "123456":
            st.success("登录成功！")
            st.session_state.logged_in = True
            st.session_state.username = username
            # 重定向到主应用
            st.experimental_rerun()
        else:
            st.error("用户名或密码错误")


if __name__ == "__main__":
    if "logged_in" not in st.session_state:
        st.session_state.logged_in = False

    if not st.session_state.logged_in:
        login_page()
    else:
        # 如果已登录，重定向到主应用
        st.switch_page("pages/app.py")