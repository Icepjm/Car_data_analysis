import unittest
import streamlit as st
from app import main_app


class TestMainApp(unittest.TestCase):
    """主应用功能测试"""

    def setUp(self):
        st.session_state.clear()
        st._last_run_callbacks = []

    def test_unauthenticated_access(self):
        """测试未登录用户访问主应用"""
        main_app()

        # 验证重定向提示
        self.assertTrue(st.warning in st._last_run_callbacks)
        self.assertTrue("login.py" in st.session_state.page_script_hash)

    def test_authenticated_access(self):
        """测试登录用户正常访问"""
        # 设置登录状态
        st.session_state.logged_in = True
        st.session_state.username = "test_user"

        main_app()

        # 验证欢迎消息
        self.assertTrue(st.title in st._last_run_callbacks)
        self.assertTrue("test_user" in st._last_run_callbacks[0][1][0])

    def test_calculation_function(self):
        """测试主应用中的计算功能"""
        # 设置登录状态
        st.session_state.logged_in = True

        # 模拟用户输入
        st.session_state["NumberInput-Value"] = [5, 10]  # 模拟两个输入框的值
        st.se