import streamlit as st


def main_app():
    """主应用页面"""
    # 检查登录状态
    if "logged_in" not in st.session_state or not st.session_state.logged_in:
        st.warning("请先登录")
        st.switch_page("login.py")
        return

    st.title(f"欢迎，{st.session_state.username}！")
    st.subheader("主应用内容")

    # 示例功能
    num1 = st.number_input("输入第一个数字", value=0)
    num2 = st.number_input("输入第二个数字", value=0)

    if st.button("相加"):
        result = num1 + num2
        st.success(f"计算结果: {num1} + {num2} = {result}")

    # 退出按钮
    if st.button("退出"):
        st.session_state.logged_in = False
        st.rerun()


if __name__ == "__main__":
    main_app()