import unittest
import streamlit as st
from login import login_page


class TestLoginPage(unittest.TestCase):
    """登录页面功能测试"""

    def setUp(self):
        st.session_state.clear()

    def test_login_success(self):
        """测试成功登录流程"""
        # 模拟用户输入正确的凭据
        st.session_state["login_form-submit_button"] = True
        st.session_state["username"] = "admin"
        st.session_state["password"] = "123456"

        login_page()  # 调用登录函数

        # 验证登录状态
        self.assertTrue(st.session_state.get("logged_in", False))
        self.assertEqual(st.session_state["username"], "admin")
        self.assertTrue(st.success in st._last_run_callbacks)

    def test_login_failure(self):
        """测试登录失败情况"""
        # 模拟用户输入错误的凭据
        st.session_state["login_form-submit_button"] = True
        st.session_state["username"] = "wrong_user"
        st.session_state["password"] = "wrong_pass"

        login_page()  # 调用登录函数

        # 验证登录失败状态
        self.assertFalse(st.session_state.get("logged_in", False))
        self.assertTrue(st.error in st._last_run_callbacks)


if __name__ == "__main__":
    unittest.main()