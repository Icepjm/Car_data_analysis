import time  # 添加time模块用于睡眠功能

import streamlit as st

def login_page():
    """图片风格还原的现代化登录页面"""
    # 自定义CSS样式
    st.markdown("""
    <style>
        body {
            background-color: #f5f7fa;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .login-header {
            margin-bottom: 28px;
            text-align: center;
        }

        /* 修改1: 将标题文字颜色改为与按钮相同的蓝色 */
        .login-header h1 {
            font-size: 28px;
            font-weight: 700;
            color: #2563eb !important; /* 使用登录按钮的颜色 */
            margin-bottom: 8px;
            letter-spacing: -0.5px;
        }

        .login-header p {
            font-size: 16px;
            color: #6b7280;
            line-height: 1.5;
            margin-bottom: 0;
        }

        /* 输入框样式 */
        .stTextInput > div > div > input, 
        .stPassword > div > div > input {
            border: 1px solid #e2e8f0 !important;
            border-radius: 10px !important;
            padding: 14px 16px !important;
            font-size: 16px !important;
            color: #1e293b !important;
            height: 52px !important;
            transition: all 0.25s ease !important;
            box-shadow: none !important;
            background: #ffffff !important;
        }

        /* 修改2: 移除输入框点击时的蓝色边框 */
        .stTextInput > div > div > input:focus, 
        .stPassword > div > div > input:focus {
            border: 1px solid #e2e8f0 !important; /* 保持原始边框颜色 */
            box-shadow: none !important; /* 移除蓝色阴影 */
        }

        .stTextInput > div > div > input::placeholder, 
        .stPassword > div > div > input::placeholder {
            color: #9ca3af !important;
        }

        /* 标签样式隐藏 */
        .stTextInput > label, .stPassword > label {
            visibility: hidden !important;
            height: 0 !important;
            margin: 0 !important;
            padding: 0 !important;
        }

        /* 密码显示按钮样式 */
        .stPassword > div > div > button {
            top: 18px !important;
            right: 12px !important;
            color: #94a3b8 !important;
            transform: scale(1.1);
            transition: all 0.2s ease !important;
        }

        .stPassword > div > div > button:hover {
            background: transparent !important;
            color: #3b82f6 !important;
        }

        /* 登录按钮样式 */
        .stButton > button {
            width: 100% !important;
            background: #2563eb !important;
            color: white !important;
            border: none !important;
            padding: 16px 20px !important;
            border-radius: 10px !important;
            font-size: 17px !important;
            font-weight: 600 !important;
            height: 54px !important;
            transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1) !important;
            box-shadow: 0 4px 6px -1px rgba(37, 99, 235, 0.3), 0 2px 4px -2px rgba(37, 99, 235, 0.3) !important;
        }

        .stButton > button:hover {
            background: #1d4ed8 !important;
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(37, 99, 235, 0.4), 0 4px 6px -4px rgba(37, 99, 235, 0.4) !important;
        }

        .stButton > button:active {
            transform: translateY(0) !important;
        }

        /* 忘记密码链接样式 */
        .forgot-password {
            text-align: center;
            margin-top: 20px;
            font-size: 15px;
        }

        .forgot-password a {
            color: #3b82f6 !important;
            text-decoration: none !important;
            font-weight: 500;
            transition: color 0.2s ease;
        }

        .forgot-password a:hover {
            color: #2563eb !important;
            text-decoration: underline !important;
        }

        /* 消息提示样式 */
        .stAlert {
            border-radius: 10px !important;
            padding: 12px 18px !important;
            margin-bottom: 20px;
        }

        /* 页面布局调整 */
        .stApp {
            background: #f5f7fa !important;
            padding: 20px !important;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .stForm {
            background: transparent !important;
            border: none !important;
            box-shadow: none !important;
            padding: 0 !important;
        }

        /* 隐藏不需要的元素 */
        header {
            display: none !important;
        }

        footer {
            display: none !important;
        }
    </style>
    """, unsafe_allow_html=True)

    # 使用Streamlit原生控件构建登录表单
    with st.form(key="login_form"):
        # 登录容器开始
        st.markdown('<div class="login-container">', unsafe_allow_html=True)

        # 登录头部 (标题和描述)
        st.markdown('<div class="login-header">', unsafe_allow_html=True)
        st.markdown('<h1>汽车销量分析系统</h1>', unsafe_allow_html=True)
        st.markdown('<p>登录以访问高级分析功能</p>', unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)

        # 用户名输入框（带占位符）
        username = st.text_input(
            "用户名",
            placeholder="请输入用户名",
            label_visibility="collapsed"
        )

        # 密码输入框（带眼睛图标切换功能）
        password = st.text_input(
            "密码",
            type="password",
            placeholder="请输入密码",
            label_visibility="collapsed"
        )

        # 登录按钮
        submit_button = st.form_submit_button("登录系统", use_container_width=True)

        # 忘记密码链接
        st.markdown('<div class="forgot-password">', unsafe_allow_html=True)
        st.markdown('<a href="#">忘记密码？</a>', unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)

        # 登录容器结束
        st.markdown('</div>', unsafe_allow_html=True)

    # 处理登录逻辑
    if submit_button:
        # 简化版验证（实际应用中应从数据库验证）
        if (username == "wx,xxx" and password == "123456")or(username == "王鑫，嘻嘻嘻" and password == "123456")or(username == "jm,xxx" and password == "123456")or(username == "ll,xxx" and password == "123456"):
            st.session_state.logged_in = True
            st.session_state.username = username
            # 显示成功消息并重定向
            st.success("登录成功！嘻嘻嘻😏")
            st.success("正在跳转...😜")
            time.sleep(3)  # 等待两秒
            st.rerun()
        elif not username or not password:
            st.error("用户名和密码不能为空")
        else:
            st.error("用户名或密码错误")


if __name__ == "__main__":
    if "logged_in" not in st.session_state:
        st.session_state.logged_in = False

    if not st.session_state.logged_in:
        login_page()
    else:
        # 如果已登录，重定向到主应用
        st.switch_page("pages/app.py")