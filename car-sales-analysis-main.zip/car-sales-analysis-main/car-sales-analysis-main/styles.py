# styles.py
def load_login_styles():
    """加载登录页面样式"""
    # 加载CSS文件
    with open("login_style.css") as f:
        css = f.read()

    # 粒子背景HTML
    particles_html = """
    <div class="particles">
        <div class="particle" style="top: 10%; left: 20%; width: 4px; height: 4px; animation-delay: 0s;"></div>
        <div class="particle" style="top: 20%; left: 70%; width: 3px; height: 3px; animation-delay: 0.5s;"></div>
        <div class="particle" style="top: 30%; left: 40%; width: 5px; height: 5px; animation-delay: 1.2s;"></div>
        <div class="particle" style="top: 40%; left: 50%; width: 2px; height: 2px; animation-delay: 0.8s;"></div>
        <div class="particle" style="top: 50%; left: 10%; width: 6px; height: 6px; animation-delay: 1.8s;"></div>
        <div class="particle" style="top: 60%; left: 80%; width: 3px; height: 3px; animation-delay: 0.3s;"></div>
        <div class="particle" style="top: 70%; left: 30%; width: 4px; height: 4px; animation-delay: 1.5s;"></div>
        <div class="particle" style="top: 80%; left: 60%; width: 3px; height: 3px; animation-delay: 2.1s;"></div>
    </div>
    """

    # 登录表单容器HTML
    login_container_html = """
    <div class="login-container">
        <div class="login-header">
            <h1>汽车销量分析系统</h1>
            <p>登录以访问高级分析功能</p>
        </div>

        <div class="login-form">
            <div class="input-group">
                <input type="text" placeholder="用户名" required id="username-input">
            </div>

            <div class="input-group">
                <input type="password" placeholder="密码" required id="password-input">
            </div>

            <button type="submit" class="login-btn" id="login-button">登录系统</button>

            <div class="forgot-password">
                <a href="#">忘记密码?</a>
            </div>

            <div class="footer">
                © 2023 汽车销量分析系统 | 版本 2.0
            </div>
        </div>
    </div>
    """

    return f"""
    <style>
        {css}
    </style>
    {particles_html}
    {login_container_html}
    """